import numpy as np
from typing import Tuple
from triton_python_model.task.classification import PostClassificationModel


class TritonPythonModel(PostClassificationModel):
    def __init__(self) -> None:
        super().__init__(input_names=["orig_img_hw"], output_names=["output"])

    def post_process_per_image(self, inputs: Tuple[np.ndarray]) -> np.ndarray:
        # Fill dummy score
        return np.array([0, 1])
