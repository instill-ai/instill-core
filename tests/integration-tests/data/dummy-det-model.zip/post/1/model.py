import numpy as np
from typing import Tuple
from triton_python_model.task.detection import PostDetectionModel


class TritonPythonModel(PostDetectionModel):
    def __init__(self) -> None:
        super().__init__(input_names=["orig_img_hw"], output_names=[
            "output_bboxes", "output_labels"])

    def post_process_per_image(self, inputs: Tuple[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        # Fill dummy bounding boxes and labels
        return np.array([[2, 5, 10, 20, 1.0]]), np.array(["test"])
